// Placeholder content shown until real entries exist in Firebase.
// Delete or overwrite via the Editor once you're logged in as owner.

export const seedInfo = {
  usar: {
    enlistmentDate: '—',
    unit: 'Unassigned',
    position: '—',
    history: 'No career history recorded yet. Add this from the Editor.',
  },
  mba: {
    enlistmentDate: '—',
    unit: 'Unassigned',
    position: '—',
    history: 'No career history recorded yet. Add this from the Editor.',
  },
}

// Ribbon-bar stripe colors are stored per-entry so each award renders a
// distinct little ribbon rather than a generic icon.
export const seedAwards = {
  'usar-ribbons': [
    {
      id: 'seed-1',
      name: 'Good Conduct Ribbon',
      dateAwarded: '—',
      citation: 'Example entry — add real ribbons from the Editor once logged in.',
      stripeColors: ['#8A9160', '#1B1E23', '#8A9160'],
    },
  ],
  'usar-badges': [],
  'usar-foreign': [],
  'usar-unit': [],
  'mba-medals': [
    {
      id: 'seed-2',
      name: 'Long Service Medal',
      dateAwarded: '—',
      citation: 'Example entry — add real medals from the Editor once logged in.',
      stripeColors: ['#7A2E2E', '#B08D3E', '#7A2E2E'],
    },
  ],
  'mba-badges': [],
  'mba-foreign': [],
}
