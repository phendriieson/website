import { useEffect, useState } from 'react'
import { AWARD_PATHS, subscribeToPath, subscribeToDoc } from '../lib/firebase.js'

function StatBlock({ label, value }) {
  return (
    <div className="stamp-corner border border-dossier-border bg-dossier-surface px-5 py-4 text-center">
      <div className="font-stamp text-2xl font-bold text-dossier-accentBright">{value}</div>
      <div className="mt-1 font-stamp text-[11px] uppercase tracking-widest2 text-dossier-dim">{label}</div>
    </div>
  )
}

export default function Home({ profile }) {
  const [counts, setCounts] = useState({})
  const [usarInfo, setUsarInfo] = useState(null)
  const [mbaInfo, setMbaInfo] = useState(null)

  useEffect(() => {
    const unsubs = Object.entries(AWARD_PATHS).map(([key, path]) =>
      subscribeToPath(path, (list) => setCounts((c) => ({ ...c, [key]: list.length })))
    )
    unsubs.push(subscribeToDoc('usar/info', setUsarInfo))
    unsubs.push(subscribeToDoc('mba/info', setMbaInfo))
    return () => unsubs.forEach((u) => u())
  }, [])

  const totalRibbonsMedals =
    (counts['usar-ribbons'] || 0) + (counts['mba-medals'] || 0)
  const totalBadges = (counts['usar-badges'] || 0) + (counts['mba-badges'] || 0)
  const totalForeign = (counts['usar-foreign'] || 0) + (counts['mba-foreign'] || 0)
  const totalUnit = counts['usar-unit'] || 0

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <div className="stamp-corner flex flex-col gap-6 border border-dossier-border bg-dossier-surface p-6 sm:flex-row sm:items-center">
        <img
          src={profile?.picture || 'https://placehold.co/120x120/1B1E23/8A9160?text=RBX'}
          alt=""
          className="h-24 w-24 shrink-0 border border-dossier-border object-cover"
        />
        <div className="min-w-0 flex-1">
          <div className="font-stamp text-[11px] uppercase tracking-widest2 text-dossier-dim">
            Service Record
          </div>
          <h1 className="mt-1 truncate font-stamp text-2xl font-bold uppercase text-dossier-text">
            {profile?.preferred_username || profile?.name || 'Not Logged In'}
          </h1>
          <div className="mt-3 flex flex-wrap gap-x-8 gap-y-1 text-sm text-dossier-dim">
            <span>USAR — {usarInfo?.position || '—'}, {usarInfo?.unit || 'Unassigned'}</span>
            <span>MBA — {mbaInfo?.position || '—'}, {mbaInfo?.unit || 'Unassigned'}</span>
          </div>
          {profile && (
            <a
              href={`https://www.roblox.com/users/${profile.sub}/profile`}
              target="_blank"
              rel="noreferrer"
              className="mt-4 inline-block border border-dossier-accentDim px-4 py-1.5 font-stamp text-xs font-bold uppercase tracking-wide text-dossier-accent hover:bg-dossier-accentDim hover:text-dossier-text"
            >
              View Roblox Profile
            </a>
          )}
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatBlock label="Ribbons / Medals" value={totalRibbonsMedals} />
        <StatBlock label="Badges" value={totalBadges} />
        <StatBlock label="Foreign Awards" value={totalForeign} />
        <StatBlock label="Unit Awards" value={totalUnit} />
      </div>
    </div>
  )
}
