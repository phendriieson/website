import { useEffect, useState } from 'react'
import { subscribeToDoc } from '../lib/firebase.js'
import { seedInfo } from '../data/seed-data.js'

export default function InfoPage({ force, title }) {
  const [info, setInfo] = useState(null)

  useEffect(() => {
    const unsub = subscribeToDoc(`${force}/info`, (val) => setInfo(val || seedInfo[force]))
    return unsub
  }, [force])

  const data = info || seedInfo[force]

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="font-stamp text-xl font-bold uppercase tracking-widest2 text-dossier-text">
        {title} — Information
      </h1>
      <div className="stamp-corner mt-6 grid grid-cols-1 gap-4 border border-dossier-border bg-dossier-surface p-6 sm:grid-cols-2">
        <div>
          <div className="font-stamp text-[11px] uppercase tracking-widest2 text-dossier-dim">Enlistment Date</div>
          <div className="mt-1 text-dossier-text">{data.enlistmentDate}</div>
        </div>
        <div>
          <div className="font-stamp text-[11px] uppercase tracking-widest2 text-dossier-dim">Current Unit</div>
          <div className="mt-1 text-dossier-text">{data.unit}</div>
        </div>
        <div>
          <div className="font-stamp text-[11px] uppercase tracking-widest2 text-dossier-dim">Chain of Command Position</div>
          <div className="mt-1 text-dossier-text">{data.position}</div>
        </div>
      </div>
      <div className="stamp-corner mt-4 border border-dossier-border bg-dossier-surface p-6">
        <div className="font-stamp text-[11px] uppercase tracking-widest2 text-dossier-dim">
          Notable Postings &amp; History
        </div>
        <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-dossier-dim">{data.history}</p>
      </div>
    </div>
  )
}
