import { useEffect, useState } from 'react'
import {
  AWARD_PATHS,
  subscribeToPath,
  subscribeToDoc,
  createEntry,
  updateEntry,
  deleteEntry,
  setDoc,
  watchOwnerAuth,
  signInOwner,
  isAdmin as checkIsAdmin,
} from '../lib/firebase.js'
import AwardCard from '../components/AwardCard.jsx'

const AWARD_CATEGORIES = [
  { key: 'usar-ribbons', label: 'USAR — Ribbons' },
  { key: 'usar-badges', label: 'USAR — Badges' },
  { key: 'usar-foreign', label: 'USAR — Foreign Awards' },
  { key: 'usar-unit', label: 'USAR — Unit Awards' },
  { key: 'mba-medals', label: 'MBA — Medals' },
  { key: 'mba-badges', label: 'MBA — Badges' },
  { key: 'mba-foreign', label: 'MBA — Foreign Awards' },
]
const INFO_CATEGORIES = [
  { key: 'usar-info', label: 'USAR — Information', path: 'usar/info' },
  { key: 'mba-info', label: 'MBA — Information', path: 'mba/info' },
]

const EMPTY_AWARD = { name: '', imageUrl: '', dateAwarded: '', citation: '', stripeColors: '#8A9160,#1B1E23,#8A9160' }
const EMPTY_INFO = { enlistmentDate: '', unit: '', position: '', history: '' }

export default function Editor() {
  const [ownerUser, setOwnerUser] = useState(null)
  const [ownerChecked, setOwnerChecked] = useState(false)
  const [ownerIsAdmin, setOwnerIsAdmin] = useState(false)

  useEffect(() => {
    const unsub = watchOwnerAuth(async (u) => {
      setOwnerUser(u)
      setOwnerIsAdmin(u ? await checkIsAdmin(u.uid) : false)
      setOwnerChecked(true)
    })
    return unsub
  }, [])

  const [category, setCategory] = useState('usar-ribbons')
  const isInfo = category.endsWith('-info')

  const [entries, setEntries] = useState([])
  const [infoDoc, setInfoDoc] = useState(EMPTY_INFO)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState(EMPTY_AWARD)
  const [mode, setMode] = useState('form') // 'form' | 'json'
  const [jsonText, setJsonText] = useState('')
  const [jsonError, setJsonError] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    setEditingId(null)
    if (isInfo) {
      const path = INFO_CATEGORIES.find((c) => c.key === category).path
      const unsub = subscribeToDoc(path, (val) => setInfoDoc(val || EMPTY_INFO))
      return unsub
    } else {
      setForm(EMPTY_AWARD)
      const unsub = subscribeToPath(AWARD_PATHS[category], setEntries)
      return unsub
    }
  }, [category])

  useEffect(() => {
    setJsonText(JSON.stringify(isInfo ? infoDoc : form, null, 2))
    setJsonError('')
  }, [form, infoDoc, isInfo])

  function applyJson() {
    try {
      const parsed = JSON.parse(jsonText)
      if (isInfo) setInfoDoc(parsed)
      else setForm(parsed)
      setJsonError('')
    } catch (e) {
      setJsonError('Invalid JSON: ' + e.message)
    }
  }

  async function saveInfo() {
    setSaving(true)
    const path = INFO_CATEGORIES.find((c) => c.key === category).path
    await setDoc(path, infoDoc)
    setSaving(false)
  }

  function toStoredAward(f) {
    return {
      name: f.name,
      imageUrl: f.imageUrl,
      dateAwarded: f.dateAwarded,
      citation: f.citation,
      stripeColors: typeof f.stripeColors === 'string'
        ? f.stripeColors.split(',').map((s) => s.trim()).filter(Boolean)
        : f.stripeColors,
    }
  }

  async function saveAward() {
    setSaving(true)
    const data = toStoredAward(form)
    if (editingId) await updateEntry(AWARD_PATHS[category], editingId, data)
    else await createEntry(AWARD_PATHS[category], data)
    setForm(EMPTY_AWARD)
    setEditingId(null)
    setSaving(false)
  }

  function editEntry(a) {
    setEditingId(a.id)
    setForm({
      name: a.name || '',
      imageUrl: a.imageUrl || '',
      dateAwarded: a.dateAwarded || '',
      citation: a.citation || '',
      stripeColors: Array.isArray(a.stripeColors) ? a.stripeColors.join(',') : a.stripeColors || '',
    })
  }

  async function removeEntry(a) {
    if (!window.confirm(`Permanently delete "${a.name}"? This cannot be undone.`)) return
    await deleteEntry(AWARD_PATHS[category], a.id)
    if (editingId === a.id) {
      setEditingId(null)
      setForm(EMPTY_AWARD)
    }
  }

  const previewAward = toStoredAward(form)

  if (!ownerChecked) {
    return <div className="p-10 font-stamp text-xs text-dossier-dim">Checking owner credentials…</div>
  }

  if (!ownerIsAdmin) {
    return (
      <div className="mx-auto max-w-md px-6 py-16 text-center">
        <h1 className="font-stamp text-lg font-bold uppercase tracking-widest2 text-dossier-text">Editor Locked</h1>
        <p className="mt-3 text-sm text-dossier-dim">
          Roblox login alone is only used for display. Database write rules require a separate Firebase
          sign-in from the account listed under <code>/admins</code> in the Realtime Database.
        </p>
        <button
          onClick={signInOwner}
          className="mt-6 border border-dossier-accentDim px-4 py-1.5 font-stamp text-xs font-bold uppercase text-dossier-accent hover:bg-dossier-accentDim hover:text-dossier-text"
        >
          Sign in with Google
        </button>
        {ownerUser && (
          <p className="mt-4 text-xs text-dossier-danger">
            Signed in as {ownerUser.email}, but this account is not in /admins. Add its UID there.
          </p>
        )}
      </div>
    )
  }

  return (
    <div className="flex h-[calc(100vh-3.5rem)] flex-col">
      <div className="flex flex-wrap items-center gap-3 border-b border-dossier-border bg-dossier-surface px-4 py-3">
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="border border-dossier-border bg-dossier-bg px-2 py-1 font-stamp text-xs text-dossier-text"
        >
          <optgroup label="Awards">
            {AWARD_CATEGORIES.map((c) => (
              <option key={c.key} value={c.key}>{c.label}</option>
            ))}
          </optgroup>
          <optgroup label="Information">
            {INFO_CATEGORIES.map((c) => (
              <option key={c.key} value={c.key}>{c.label}</option>
            ))}
          </optgroup>
        </select>

        <div className="ml-auto flex gap-1 border border-dossier-border">
          <button
            onClick={() => setMode('form')}
            className={`px-3 py-1 font-stamp text-xs ${mode === 'form' ? 'bg-dossier-accentDim text-dossier-text' : 'text-dossier-dim'}`}
          >
            Form
          </button>
          <button
            onClick={() => setMode('json')}
            className={`px-3 py-1 font-stamp text-xs ${mode === 'json' ? 'bg-dossier-accentDim text-dossier-text' : 'text-dossier-dim'}`}
          >
            Raw JSON
          </button>
        </div>
      </div>

      <div className="flex flex-1 flex-col overflow-hidden md:flex-row">
        {/* Left: editor */}
        <div className="w-full overflow-y-auto border-b border-dossier-border p-4 md:w-1/2 md:border-b-0 md:border-r">
          {!isInfo && (
            <>
              <div className="mb-4 space-y-1">
                {entries.map((a) => (
                  <div key={a.id} className="flex items-center justify-between border border-dossier-border bg-dossier-surface px-3 py-2 text-sm">
                    <span className="truncate text-dossier-text">{a.name}</span>
                    <div className="flex gap-3 font-stamp text-[11px] uppercase">
                      <button onClick={() => editEntry(a)} className="text-dossier-accent hover:text-dossier-accentBright">Edit</button>
                      <button onClick={() => removeEntry(a)} className="text-dossier-danger hover:text-red-400">Delete</button>
                    </div>
                  </div>
                ))}
                {entries.length === 0 && <p className="text-xs text-dossier-dim">No entries yet in this category.</p>}
              </div>
              <div className="border-t border-dossier-border pt-4">
                <p className="mb-2 font-stamp text-xs uppercase tracking-widest2 text-dossier-dim">
                  {editingId ? 'Edit Entry' : 'New Entry'}
                </p>
              </div>
            </>
          )}

          {mode === 'form' ? (
            isInfo ? (
              <div className="space-y-3">
                <Field label="Enlistment Date" value={infoDoc.enlistmentDate} onChange={(v) => setInfoDoc({ ...infoDoc, enlistmentDate: v })} />
                <Field label="Current Unit / Regiment" value={infoDoc.unit} onChange={(v) => setInfoDoc({ ...infoDoc, unit: v })} />
                <Field label="Chain of Command Position" value={infoDoc.position} onChange={(v) => setInfoDoc({ ...infoDoc, position: v })} />
                <Field label="History" textarea value={infoDoc.history} onChange={(v) => setInfoDoc({ ...infoDoc, history: v })} />
                <button
                  onClick={saveInfo}
                  disabled={saving}
                  className="border border-dossier-accentDim px-4 py-1.5 font-stamp text-xs font-bold uppercase text-dossier-accent hover:bg-dossier-accentDim hover:text-dossier-text disabled:opacity-50"
                >
                  {saving ? 'Saving…' : 'Save Changes'}
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <Field label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
                <Field label="Image URL (optional)" value={form.imageUrl} onChange={(v) => setForm({ ...form, imageUrl: v })} />
                <Field label="Date Awarded" value={form.dateAwarded} onChange={(v) => setForm({ ...form, dateAwarded: v })} />
                <Field label="Citation / Reason" textarea value={form.citation} onChange={(v) => setForm({ ...form, citation: v })} />
                <Field
                  label="Ribbon Stripe Colors (comma-separated hex, used if no image)"
                  value={form.stripeColors}
                  onChange={(v) => setForm({ ...form, stripeColors: v })}
                />
                <div className="flex gap-2">
                  <button
                    onClick={saveAward}
                    disabled={saving || !form.name}
                    className="border border-dossier-accentDim px-4 py-1.5 font-stamp text-xs font-bold uppercase text-dossier-accent hover:bg-dossier-accentDim hover:text-dossier-text disabled:opacity-50"
                  >
                    {saving ? 'Saving…' : editingId ? 'Update Entry' : 'Add Entry'}
                  </button>
                  {editingId && (
                    <button
                      onClick={() => { setEditingId(null); setForm(EMPTY_AWARD) }}
                      className="border border-dossier-border px-4 py-1.5 font-stamp text-xs uppercase text-dossier-dim hover:text-dossier-text"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </div>
            )
          ) : (
            <div>
              <textarea
                value={jsonText}
                onChange={(e) => setJsonText(e.target.value)}
                spellCheck={false}
                className="h-64 w-full border border-dossier-border bg-dossier-bg p-3 font-stamp text-xs text-dossier-text"
              />
              {jsonError && <p className="mt-1 text-xs text-dossier-danger">{jsonError}</p>}
              <button
                onClick={applyJson}
                className="mt-2 border border-dossier-border px-4 py-1.5 font-stamp text-xs uppercase text-dossier-dim hover:text-dossier-text"
              >
                Apply JSON to form
              </button>
              <p className="mt-2 text-xs text-dossier-dim">
                Applying loads this JSON into the form above; use Save / Add Entry there to write it to Firebase.
              </p>
            </div>
          )}
        </div>

        {/* Right: live preview */}
        <div className="w-full overflow-y-auto bg-dossier-bg/60 p-6 md:w-1/2">
          <p className="mb-3 font-stamp text-xs uppercase tracking-widest2 text-dossier-dim">Live Preview</p>
          {isInfo ? (
            <div className="stamp-corner border border-dossier-border bg-dossier-surface p-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="text-dossier-dim">Enlistment Date</span><div className="text-dossier-text">{infoDoc.enlistmentDate || '—'}</div></div>
                <div><span className="text-dossier-dim">Unit</span><div className="text-dossier-text">{infoDoc.unit || '—'}</div></div>
                <div><span className="text-dossier-dim">Position</span><div className="text-dossier-text">{infoDoc.position || '—'}</div></div>
              </div>
              <p className="mt-4 whitespace-pre-line text-sm text-dossier-dim">{infoDoc.history || 'No history entered.'}</p>
            </div>
          ) : (
            <AwardCard award={{ ...previewAward, id: 'preview' }} editable={false} />
          )}
        </div>
      </div>
    </div>
  )
}

function Field({ label, value, onChange, textarea }) {
  const common = 'w-full border border-dossier-border bg-dossier-bg px-3 py-2 text-sm text-dossier-text'
  return (
    <label className="block">
      <span className="mb-1 block font-stamp text-[11px] uppercase tracking-widest2 text-dossier-dim">{label}</span>
      {textarea ? (
        <textarea rows={4} value={value} onChange={(e) => onChange(e.target.value)} className={common} />
      ) : (
        <input value={value} onChange={(e) => onChange(e.target.value)} className={common} />
      )}
    </label>
  )
}
