import { useEffect, useState } from 'react'
import { AWARD_PATHS, subscribeToPath } from '../lib/firebase.js'
import { seedAwards } from '../data/seed-data.js'
import AwardCard from '../components/AwardCard.jsx'

export default function AwardsPage({ pathKey, title }) {
  const [awards, setAwards] = useState(null)

  useEffect(() => {
    const unsub = subscribeToPath(AWARD_PATHS[pathKey], (list) => setAwards(list))
    return unsub
  }, [pathKey])

  const list = awards && awards.length ? awards : awards?.length === 0 ? (seedAwards[pathKey] || []) : null

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <div className="flex items-center justify-between">
        <h1 className="font-stamp text-xl font-bold uppercase tracking-widest2 text-dossier-text">{title}</h1>
        <span className="font-stamp text-xs text-dossier-dim">{list ? list.length : '—'} entries</span>
      </div>

      {list === null && <p className="mt-8 text-sm text-dossier-dim">Loading records…</p>}

      {list && list.length === 0 && (
        <div className="mt-8 border border-dashed border-dossier-border p-8 text-center text-sm text-dossier-dim">
          No entries recorded yet. Log in as the owner and use the Editor to add the first one.
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {list && list.map((a) => <AwardCard key={a.id} award={a} editable={false} />)}
      </div>
    </div>
  )
}
