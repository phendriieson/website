import { useEffect, useState } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Sidebar from './components/Sidebar.jsx'
import TopBar from './components/TopBar.jsx'
import Home from './pages/Home.jsx'
import InfoPage from './pages/InfoPage.jsx'
import AwardsPage from './pages/AwardsPage.jsx'
import Editor from './pages/Editor.jsx'
import { startLogin, logout, handleRedirectIfPresent, getStoredProfile } from './lib/roblox-auth.js'
import { isAdmin as checkIsAdmin } from './lib/firebase.js'

export default function App() {
  const [profile, setProfile] = useState(getStoredProfile())
  const [admin, setAdmin] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    handleRedirectIfPresent().then((p) => {
      if (p) setProfile(p)
    })
  }, [])

  useEffect(() => {
    if (profile?.sub) {
      checkIsAdmin(profile.sub).then(setAdmin)
    } else {
      setAdmin(false)
    }
  }, [profile])

  function handleLogout() {
    logout()
    setProfile(null)
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar isAdmin={admin} mobileOpen={mobileOpen} onCloseMobile={() => setMobileOpen(false)} />
      <div className="flex min-h-screen flex-1 flex-col">
        <TopBar
          profile={profile}
          onLogin={startLogin}
          onLogout={handleLogout}
          onToggleMobile={() => setMobileOpen((o) => !o)}
        />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home profile={profile} />} />

            <Route path="/usar/information" element={<InfoPage force="usar" title="USAR" />} />
            <Route path="/usar/ribbons" element={<AwardsPage pathKey="usar-ribbons" title="USAR — Ribbons" />} />
            <Route path="/usar/badges" element={<AwardsPage pathKey="usar-badges" title="USAR — Badges" />} />
            <Route path="/usar/foreign-awards" element={<AwardsPage pathKey="usar-foreign" title="USAR — Foreign Awards" />} />
            <Route path="/usar/unit-awards" element={<AwardsPage pathKey="usar-unit" title="USAR — Unit Awards" />} />

            <Route path="/mba/information" element={<InfoPage force="mba" title="MBA" />} />
            <Route path="/mba/medals" element={<AwardsPage pathKey="mba-medals" title="MBA — Medals" />} />
            <Route path="/mba/badges" element={<AwardsPage pathKey="mba-badges" title="MBA — Badges" />} />
            <Route path="/mba/foreign-awards" element={<AwardsPage pathKey="mba-foreign" title="MBA — Foreign Awards" />} />

            <Route
              path="/editor"
              element={admin ? <Editor /> : <Navigate to="/" replace />}
            />

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}
