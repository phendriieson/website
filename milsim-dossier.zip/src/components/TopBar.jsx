export default function TopBar({ profile, onLogin, onLogout, onToggleMobile }) {
  return (
    <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-dossier-border bg-dossier-bg/95 px-4 backdrop-blur">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleMobile}
          className="border border-dossier-border px-2 py-1 font-stamp text-xs text-dossier-dim md:hidden"
          aria-label="Toggle navigation"
        >
          ☰
        </button>
        <div className="h-6 w-6 border border-dossier-accent" aria-hidden="true" />
        <span className="font-stamp text-sm font-bold uppercase tracking-widest2 text-dossier-text">
          Personnel Dossier
        </span>
      </div>

      {profile ? (
        <button
          onClick={onLogout}
          className="flex items-center gap-2 border border-dossier-border px-3 py-1.5 hover:border-dossier-accentDim"
          title="Log out"
        >
          {profile.picture && (
            <img src={profile.picture} alt="" className="h-6 w-6 rounded-none object-cover" />
          )}
          <span className="font-stamp text-xs text-dossier-text">
            {profile.preferred_username || profile.name}
          </span>
        </button>
      ) : (
        <button
          onClick={onLogin}
          className="border border-dossier-accentDim px-4 py-1.5 font-stamp text-xs font-bold uppercase tracking-wide text-dossier-accent hover:bg-dossier-accentDim hover:text-dossier-text"
        >
          Login
        </button>
      )}
    </header>
  )
}
