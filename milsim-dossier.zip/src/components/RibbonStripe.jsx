export default function RibbonStripe({ colors = [], className = '' }) {
  const stripes = colors.length ? colors : ['#565C3B', '#8A9160', '#565C3B']
  return (
    <div className={`flex h-6 w-16 overflow-hidden rounded-[1px] ring-1 ring-black/40 ${className}`}>
      {stripes.map((c, i) => (
        <div key={i} style={{ backgroundColor: c }} className="flex-1" />
      ))}
    </div>
  )
}
