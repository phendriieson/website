import RibbonStripe from './RibbonStripe.jsx'

export default function AwardCard({ award, onEdit, onDelete, editable }) {
  return (
    <div className="stamp-corner group flex gap-4 border border-dossier-border bg-dossier-surface p-4 transition-colors hover:border-dossier-accentDim">
      <div className="flex flex-col items-center gap-2 pt-1">
        {award.imageUrl ? (
          <img src={award.imageUrl} alt="" className="h-10 w-10 object-contain" />
        ) : (
          <RibbonStripe colors={award.stripeColors} />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-3">
          <h3 className="truncate font-stamp text-sm font-bold uppercase tracking-wide text-dossier-text">
            {award.name}
          </h3>
          <span className="shrink-0 font-stamp text-[11px] text-dossier-dim">
            {award.dateAwarded || '—'}
          </span>
        </div>
        {award.citation && (
          <p className="mt-2 text-sm leading-relaxed text-dossier-dim">{award.citation}</p>
        )}
        {editable && (
          <div className="mt-3 flex gap-3 text-[11px] font-stamp uppercase tracking-wide opacity-0 transition-opacity group-hover:opacity-100">
            <button onClick={() => onEdit(award)} className="text-dossier-accent hover:text-dossier-accentBright">
              Edit
            </button>
            <button onClick={() => onDelete(award)} className="text-dossier-danger hover:text-red-400">
              Delete
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
