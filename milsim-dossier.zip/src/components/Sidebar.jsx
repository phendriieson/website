import { useState } from 'react'
import { NavLink } from 'react-router-dom'

const SECTIONS = [
  {
    code: 'USAR',
    label: 'United States Army',
    items: [
      { to: '/usar/information', label: 'Information' },
      { to: '/usar/ribbons', label: 'Ribbons' },
      { to: '/usar/badges', label: 'Badges' },
      { to: '/usar/foreign-awards', label: 'Foreign Awards' },
      { to: '/usar/unit-awards', label: 'Unit Awards' },
    ],
  },
  {
    code: 'MBA',
    label: 'British Army',
    items: [
      { to: '/mba/information', label: 'Information' },
      { to: '/mba/medals', label: 'Medals' },
      { to: '/mba/badges', label: 'Badges' },
      { to: '/mba/foreign-awards', label: 'Foreign Awards' },
    ],
  },
]

function NavItem({ to, label }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `block border-l-2 py-1.5 pl-4 pr-2 text-sm transition-colors ${
          isActive
            ? 'border-dossier-accent bg-dossier-surface2 text-dossier-accentBright'
            : 'border-transparent text-dossier-dim hover:border-dossier-accentDim hover:text-dossier-text'
        }`
      }
    >
      {label}
    </NavLink>
  )
}

function Section({ section, defaultOpen }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="border-b border-dossier-border">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between px-4 py-3 text-left"
        aria-expanded={open}
      >
        <span className="font-stamp text-xs font-bold uppercase tracking-widest2 text-dossier-accent">
          {section.code}
          <span className="ml-2 hidden font-serif text-[11px] font-normal normal-case tracking-normal text-dossier-dim md:inline">
            {section.label}
          </span>
        </span>
        <span className="font-stamp text-xs text-dossier-dim">{open ? '−' : '+'}</span>
      </button>
      {open && <div className="flex flex-col gap-0.5 pb-3">{section.items.map((i) => <NavItem key={i.to} {...i} />)}</div>}
    </div>
  )
}

export default function Sidebar({ isAdmin, mobileOpen, onCloseMobile }) {
  return (
    <>
      {mobileOpen && (
        <div className="fixed inset-0 z-30 bg-black/60 md:hidden" onClick={onCloseMobile} />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 shrink-0 transform overflow-y-auto border-r border-dossier-border bg-dossier-bg transition-transform md:static md:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="border-b border-dossier-border px-4 py-4">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `block font-stamp text-xs font-bold uppercase tracking-widest2 ${
                isActive ? 'text-dossier-accentBright' : 'text-dossier-dim hover:text-dossier-text'
              }`
            }
          >
            ▸ Home
          </NavLink>
        </div>
        {SECTIONS.map((s, idx) => (
          <Section key={s.code} section={s} defaultOpen={idx === 0} />
        ))}
        {isAdmin && (
          <div className="px-4 py-4">
            <NavLink
              to="/editor"
              className={({ isActive }) =>
                `block font-stamp text-xs font-bold uppercase tracking-widest2 ${
                  isActive ? 'text-dossier-accentBright' : 'text-dossier-gold hover:text-dossier-accentBright'
                }`
              }
            >
              ▸ Editor
            </NavLink>
          </div>
        )}
      </aside>
    </>
  )
}
